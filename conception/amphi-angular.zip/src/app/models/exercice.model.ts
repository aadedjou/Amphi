export interface Exercice {
  name: string;
  type: string;
  question: string;
}

