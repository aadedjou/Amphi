import { Component, OnInit } from '@angular/core';
import { Cours } from './models/cours.model';
import { CoursService } from './services/cours.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  index = 0;
  editMode : boolean = false;
  saisie = '';
  saisieDesc = '';
  selection: Cours;
  slides: Cours[];

  constructor(
    private readonly cours: CoursService
  ) {}

  ngOnInit() {
    this.slides = this.cours.getCours();
    this.selection = this.slides[0];
  }

  nextSlide() {
    if (this.index < this.slides.length) this.index++;
  }

  prevSlide() {
    if (this.index >= 0) this.index--;
  }
}
