export interface Cours {
  title: string;
  contenu: string;
}

